# -*- coding: utf-8 -*-
import client.extraClientApi as clientApi
from mcBacteriaMod import logger
from mcBacteriaMod.modCommon.config.const import Const

ClientSystem = clientApi.GetClientSystemCls()


class Client(ClientSystem):

    def __init__(self, namespace, system_name):
        ClientSystem.__init__(self, namespace, system_name)
        logger.info("---客户端开始监听事件---")
        self.__playerId = clientApi.GetLocalPlayerId()
        self.__levelId = clientApi.GetLevelId()
        self.__current_ui = None

        self.listenEvent()

    def listenEvent(self):
        # 注册自定义事件
        self.DefineEvent(Const.clientUIFinishedEvent)
        self.DefineEvent(Const.clientClickButtonEvent)
        self.DefineEvent(Const.clientTickEvent)
        # 监听系统事件
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(),
                            "UiInitFinished", self, self.onUIInitFinished)
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(),
                            "OnScriptTickClient", self, self.onTick)
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(),
                            "OnCarriedNewItemChangedClientEvent", self, self.OnCarriedNewItemChangedClientEvent)

        # 监听自定义事件
        self.ListenForEvent(Const.modName, Const.serverSystemName, Const.serverCheckPlayerCarriedItemEvent,
                            self, self.OnCarriedNewItemChangedClientEvent)

    def onUIInitFinished(self, data):
        logger.info("注册UI")
        # 注册UI
        for (key, clsPath, nameSpace) in Const.uiList:
            clientApi.RegisterUI(Const.modName, key, clsPath, nameSpace)
            # todo 创建并加载UI 根据需要重写或删除
            clientApi.CreateUI(Const.modName, key, {"isHud": 1})

        self.__current_ui = clientApi.GetUI(Const.modName, Const.BacteriaModUIKey)
        if self.__current_ui:
            self.__current_ui.init(self)
            data = self.CreateEventData()
            data["player_id"] = self.__playerId
            comp = clientApi.CreateComponent(self.__playerId, "Minecraft", "item")
            carriedItem = comp.GetCarriedItem()
            if carriedItem and carriedItem["itemName"] == Const.Sterilizer:
                self.__current_ui.set_common_btn_visible(True)
            self.NotifyToServer(Const.clientUIFinishedEvent, data)
        else:
            logger.error("create ui failed!")

    def onTick(self):
        pass

    def OnCarriedNewItemChangedClientEvent(self, data):
        itemName = data.get("itemName")
        if self.__current_ui:
            if itemName == Const.Sterilizer:
                self.__current_ui.set_common_btn_visible(True)
            else:
                self.__current_ui.set_common_btn_visible(False)

    # todo 组件更新设置，根据需要重写或置空
    def updateComponents(self):
        pass

    # 引擎调用，2 tick调用一次
    def Update(self):
        # self.updateComponents()
        pass

    def Destroy(self):
        pass
