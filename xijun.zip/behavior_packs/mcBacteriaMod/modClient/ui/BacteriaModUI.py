# -*- coding: utf-8 -*-

import client.extraClientApi as clientApi
from mcBacteriaMod import logger
from mcBacteriaMod.modCommon.config.const import Const

ViewBinder = clientApi.GetViewBinderCls()
ViewRequest = clientApi.GetViewViewRequestCls()
ScreenNode = clientApi.GetScreenNodeCls()


class BacteriaModUI(ScreenNode):
    def __init__(self, namespace, name, param):
        ScreenNode.__init__(self, namespace, name, param)
        self.__playerId = clientApi.GetLocalPlayerId()
        self.__btnPanel = "/buttonPanel"
        self.__btnPanelBackgroundImage = self.__btnPanel + "/buttonPanelBackgroundImage"
        self.__btnCommon = self.__btnPanel + "/button_common"
        self.__btnList = [self.__btnCommon]
        self.__client = None

    # 引擎调用函数, UI创建成功时调用
    def Create(self):
        self.AddTouchEventHandler(self.__btnCommon, self.on_common_click, {"isSwallow": True})

    def init(self, client):
        self.__client = client

    def set_common_btn_visible(self, val):
        self.SetVisible(self.__btnCommon, val)

    def tick(self):
        pass

    def close_all_ui(self):
        for btn in self.__btnList:
            self.SetVisible(btn, False)

    @ViewBinder.binding(ViewBinder.BF_ButtonClickUp)
    def on_common_click(self, args):
        touchEventEnum = clientApi.GetMinecraftEnum().TouchEvent
        if args["TouchEvent"] == touchEventEnum.TouchUp:
            data = self.__client.CreateEventData()
            data["playerId"] = self.__playerId
            itemComp = self.__client.CreateComponent(self.__playerId, Const.minecraft, "item")
            if itemComp.carriedItem:
                itemId = itemComp.carriedItem.get("itemName", None)
                if itemId == Const.Sterilizer:
                    data["itemId"] = itemId
                    self.__client.NotifyToServer(Const.clientClickButtonEvent, data)
        return ViewRequest.Refresh