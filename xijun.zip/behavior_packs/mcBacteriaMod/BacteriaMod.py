# -*- coding: utf-8 -*-


class BacteriaMod(object):
    bacteria = None
    growBacteria = None











