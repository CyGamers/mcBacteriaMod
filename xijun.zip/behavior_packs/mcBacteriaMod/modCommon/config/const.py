# -*- coding: utf-8 -*-


class Const(object):
    # todo MOD名需要重写
    modName = "BacteriaMod"

    modVersion = "0.0.1"
    minecraft = "Minecraft"

    # Server System
    serverSystemName = "BacteriaServerSystem"
    serverSystemClsPath = "mcBacteriaMod.modServer.serverSystem.Server"

    # Client System
    clientSystemName = "BacteriaClientSystem"
    clientSystemClsPath = "mcBacteriaMod.modClient.clientSystem.Client"

    # Custom Component
    # componentList不可删除，可置空
    componentList = []

    # todo 自定义事件，根据需要编写
    # Server Custom Event
    serverCheckPlayerCarriedItemEvent = "serverCheckPlayerCarriedItemEvent"
    # Client Custom Event
    clientUIFinishedEvent = "ClientUIFinishedEvent"
    clientClickButtonEvent = "ClientClickButtonEvent"
    clientTickEvent = "clientTickEvent"

    # UI
    # uiList不可删除，可置空
    BacteriaModUIKey = "BacteriaModUI"
    BacteriaModUIClsPath = "mcBacteriaMod.modClient.ui.BacteriaModUI.BacteriaModUI"
    BacteriaModUINameSpace = "BacteriaModUI.main"
    uiList = [(BacteriaModUIKey, BacteriaModUIClsPath, BacteriaModUINameSpace)]
    # uiList = []

    # Block
    Bacteria = "BacteriaMod:BacteriaMod_Bacteria"
    GrowBacteria = "BacteriaMod:BacteriaMod_GrowBacteria"
    SterilizeBlock = "BacteriaMod:BacteriaMod_SterilizeBlock"

    #Item
    Sterilizer = "bacteriamod:bacteriamod_sterilizer"






