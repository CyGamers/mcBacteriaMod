# -*- coding: utf-8 -*-


class Task(object):
    def __init__(self, task, delay, repeatTimes, *args, **kwargs):
        self.__task = task
        self.__delay = delay
        self.__repeatTimes = repeatTimes
        self.__args = args
        self.__kwargs = kwargs
        self.__finished = False

    @property
    def isFinished(self):
        return self.__finished

    def run(self):
        if self.__delay > 0:
            self.__delay -= 1
        else:
            if self.__repeatTimes > 0:

                # Peter_20_08_04 把下面的语句换成if_else语句
                # self.__task(self.__args, self.__kwargs)
                if self.__args:
                    if self.__kwargs:
                        self.__task(self.__args, self.__kwargs)
                    else:
                        self.__task(self.__args)
                else:
                    self.__task()

                self.__repeatTimes -= 1
            else:
                self.__finished = True







