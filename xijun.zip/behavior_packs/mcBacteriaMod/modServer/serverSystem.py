# -*- coding: utf-8 -*-
import server.extraServerApi as serverApi
from mcBacteriaMod.Blocks.Bacteria import Bacteria
from mcBacteriaMod.Blocks.GrowBacteriaBlock import GrowBacteriaBlock
from mcBacteriaMod import logger
from mcBacteriaMod.modCommon.config.const import Const
from mcBacteriaMod.BacteriaMod import BacteriaMod as Mod

ServerSystem = serverApi.GetServerSystemCls()


class Server(ServerSystem):
    def __init__(self, namespace, system_name):
        ServerSystem.__init__(self, namespace, system_name)
        self.__levelId = serverApi.GetLevelId()
        self.__playerIdList = []
        self.listenEvent()

    # 监听事件
    def listenEvent(self):
        # todo 注册自定义事件，根据需要重写或删除
        self.DefineEvent(Const.serverCheckPlayerCarriedItemEvent)
        # 监听系统事件
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                            "LoadServerAddonScriptsAfter", self, self.init)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                            "OnScriptTickServer", self, self.onTick)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                            "AddServerPlayerEvent", self, self.onAddPlayer)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                            'BlockStrengthChangedServerEvent', self, self.BlockStrengthChangedServerEvent)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                            'ServerBlockEntityTickEvent', self, self.ServerBlockEntityTickEvent)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                            'ServerPlaceBlockEntityEvent', self, self.ServerPlaceBlockEntityEvent)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(),
                            'ServerEntityTryPlaceBlockEvent', self, self.ServerEntityTryPlaceBlockEvent)

        # 监听自定义事件
        self.ListenForEvent(Const.modName, Const.clientSystemName, Const.clientUIFinishedEvent,
                            self, self.onUIFinished)
        self.ListenForEvent(Const.modName, Const.clientSystemName, Const.clientClickButtonEvent,
                            self, self.onClick)
        self.ListenForEvent(Const.modName, Const.clientSystemName, Const.clientTickEvent,
                            self, self.onClientTick)

    def init(self, data):
        comp = serverApi.CreateComponent(self.__levelId, Const.minecraft, "blockUseEventWhiteList")
        comp.AddBlockItemListenForUseEvent("minecraft:cobblestone")
        Mod.bacteria = Bacteria(data, self.__levelId)
        Mod.growBacteria = GrowBacteriaBlock(data, self.__levelId)

    def onUIFinished(self, data):
        pass

    def onTick(self):
        pass

    def ServerEntityTryPlaceBlockEvent(self, data):
        pass

    def onClientTick(self, data):
        pass

    def ServerPlaceBlockEntityEvent(self, data):
        name = data["blockName"]
        if Mod.bacteria and name == Const.Bacteria:
            Mod.bacteria.ServerPlaceBlockEntityEvent(data)
        elif Mod.growBacteria and name == Const.GrowBacteria:
            Mod.growBacteria.ServerPlaceBlockEntityEvent(data)

    def BlockStrengthChangedServerEvent(self, data):
        name = data["blockName"]
        if Mod.bacteria and name == Const.Bacteria:
            Mod.bacteria.BlockStrengthChangedServerEvent(data, self.__playerIdList[0])
        elif Mod.growBacteria and name == Const.GrowBacteria:
            Mod.growBacteria.BlockStrengthChangedServerEvent(data, self.__playerIdList[0])

    def ServerBlockEntityTickEvent(self, data):
        name = data["blockName"]
        if Mod.bacteria and name == Const.Bacteria:
            Mod.bacteria.ServerBlockEntityTickEvent(data, self.__playerIdList[0])
        elif Mod.growBacteria and name == Const.GrowBacteria:
            Mod.growBacteria.ServerBlockEntityTickEvent(data, self.__playerIdList[0])

    def onAddPlayer(self, data):
        playerId = data.get("id", "-1")
        if playerId == "-1":
            return
        self.__playerIdList.append(playerId)

    def onClick(self, data):
        if data["itemId"] == Const.Sterilizer:
            clearCnt = Mod.bacteria.clear() + Mod.growBacteria.clear()
            msgComp = serverApi.CreateComponent(data["playerId"], Const.minecraft, "msg")
            nameComp = serverApi.CreateComponent(data["playerId"], "Minecraft", "name")
            playerName = nameComp.GetName()
            msgComp.SendMsg(playerName, "细菌干扰器：共干扰了" + str(clearCnt) + "个方块")

    # 引擎调用，2 tick调用一次
    def Update(self):
        pass
